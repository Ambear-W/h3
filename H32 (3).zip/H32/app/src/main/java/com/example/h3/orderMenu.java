package com.example.h3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class orderMenu extends AppCompatActivity {

    private Button drinks;
    private Button entrees;
    private Button sweets;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_menu);

        drinks = (Button) findViewById(R.id.drinkButton);
        entrees = (Button) findViewById(R.id.entreeButton);
        sweets = (Button) findViewById(R.id.sweetsButton);

        drinks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent drinksScreen = new Intent(orderMenu.this, drinkMenu.class);
                startActivity(drinksScreen);
            }
        });

        entrees.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent entreesScreen = new Intent(orderMenu.this, entreeMenu.class);
                startActivity(entreesScreen);
            }
        });

        sweets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sweetsScreen = new Intent(orderMenu.this, sweetMenu.class);
                startActivity(sweetsScreen);
            }
        });
    }
}
