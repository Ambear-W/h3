package com.example.h3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class entreeMenu extends AppCompatActivity {

    private Button pizzaButton, pastaButton, steakButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entree_menu);

        pizzaButton = (Button) findViewById(R.id.pizzaButton);
        pastaButton = (Button) findViewById(R.id.pastaButton);
        steakButton = (Button) findViewById(R.id.steakButton);

        pizzaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pizzaScreen = new Intent(entreeMenu.this, pizzaScreen.class);
                startActivity(pizzaScreen);
            }
        });
    }
}
