package com.example.h3;

import android.content.Intent;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class scanMenu extends AppCompatActivity {

    private Button manSearch;
    private Button yum;
    private Button tasty;
    private EditText location;
    private EditText zip;
    private Button comfirm;
    private Button yumBut;
    private Button tastyBut;
    private ImageView yumPic;
    private ImageView tastyPic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_menu);

        manSearch = (Button) findViewById(R.id.manSearchButton);
        location = (EditText) findViewById(R.id.locationName);
        zip = (EditText) findViewById(R.id.zipCode);

        yumBut = (Button) findViewById(R.id.resturant1Button);
        tastyBut = (Button) findViewById(R.id.resturant2Button);

        yumPic = (ImageView) findViewById(R.id.rest1);
        tastyPic = (ImageView) findViewById(R.id.rest2);

        manSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                location.setVisibility(View.VISIBLE);
                zip.setVisibility(View.VISIBLE);
                comfirm.setVisibility(View.VISIBLE);
                manSearch.setVisibility(View.INVISIBLE);
            }
        });

        comfirm = (Button) findViewById(R.id.searchButton);

        comfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yumBut.setVisibility(View.VISIBLE);
                tastyBut.setVisibility(View.VISIBLE);

                yumPic.setVisibility(View.VISIBLE);
                tastyPic.setVisibility(View.VISIBLE);
            }
        });

        yum = (Button) findViewById(R.id.resturant1Button);

        yum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent orderScreen =new Intent(scanMenu.this, orderMenu.class);
                startActivity(orderScreen);
            }
        });

        tasty = (Button) findViewById(R.id.resturant2Button);

        tasty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent orderScreen = new Intent (scanMenu.this, orderMenu.class);
                startActivity(orderScreen);
            }
        });
    }
}
