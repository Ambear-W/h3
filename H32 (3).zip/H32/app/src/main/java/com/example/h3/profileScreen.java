package com.example.h3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class profileScreen extends AppCompatActivity {

    private TextView name;
    private EditText editName;
    private Button editNameButton, setNameButton, dietButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_screen);

        name = (TextView) findViewById(R.id.name);
        editName = (EditText) findViewById(R.id.editName);
        editNameButton = (Button) findViewById(R.id.editNameButton);
        setNameButton = (Button) findViewById(R.id.setNameButton);
        dietButton = (Button) findViewById(R.id.deitButton);

        editNameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name.setVisibility(View.INVISIBLE);
                editNameButton.setVisibility(View.INVISIBLE);

                editName.setVisibility(View.VISIBLE);
                setNameButton.setVisibility(View.VISIBLE);
            }
        });

        setNameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name.setText(editName.getText().toString());

                editName.setVisibility(View.INVISIBLE);
                name.setVisibility(View.VISIBLE);
            }
        });

        dietButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent dietScreen = new Intent(profileScreen.this, dietSelection.class);
                startActivity(dietScreen);
            }
        });
    }
}
