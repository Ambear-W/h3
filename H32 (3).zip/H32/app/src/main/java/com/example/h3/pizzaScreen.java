package com.example.h3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class pizzaScreen extends AppCompatActivity {

    private Button addButton;
    private RadioGroup sizes;
    private RadioButton small, med, large;
    private TextView total;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizza_screen);

        addButton = (Button) findViewById(R.id.addButton);
        small = (RadioButton) findViewById(R.id.smallPizza);
        med = (RadioButton) findViewById(R.id.mediumPizza);
        large = (RadioButton) findViewById(R.id.largePizza);

        sizes = (RadioGroup) findViewById(R.id.radioGroupSize);
        total = (TextView) findViewById(R.id.totalAmount);

        sizes.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.smallPizza){
                    total.setText("$5.00");
                }else if(checkedId == R.id.mediumPizza){
                    total.setText("$10.00");
                }else if(checkedId == R.id.largePizza){
                    total.setText("$15.00");
                }else{
                    total.setText("$0.00");
                }
            }
        });
    }
}
