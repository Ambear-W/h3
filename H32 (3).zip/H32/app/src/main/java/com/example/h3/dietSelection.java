package com.example.h3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Switch;

public class dietSelection extends AppCompatActivity {

    Switch veganSwitch, vegiSwitch, dairySwitch, glutenSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet_selection);

        veganSwitch = (Switch) findViewById(R.id.veganSwitch);
        vegiSwitch = (Switch) findViewById(R.id.vegiSwitch);
        dairySwitch = (Switch) findViewById(R.id.dairySwitch);
        glutenSwitch = (Switch) findViewById(R.id.gluteenSwitch);

    }
}
