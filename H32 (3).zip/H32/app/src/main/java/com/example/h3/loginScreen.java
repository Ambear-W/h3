package com.example.h3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class loginScreen extends AppCompatActivity {

    private EditText name;
    private EditText password;
    private Button login;
    private TextView errorMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

        name = (EditText) findViewById(R.id.userNameLogin);
        password = (EditText) findViewById(R.id.passwordLogin);
        login = (Button) findViewById(R.id.loginButtonLogin);
        errorMessage = (TextView) findViewById(R.id.incorrectInformation);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                comfrim(name.getText().toString(), password.getText().toString());
            }
        });

    }

    private void comfrim(String userName, String userPassword){
        if(userName.equals("Amber") && userPassword.equals("1234")){
            Intent scanScreen = new Intent(loginScreen.this, mainMenu.class);
            startActivity(scanScreen);
        }else{
            errorMessage.setVisibility(View.VISIBLE);
        }
    }
}
