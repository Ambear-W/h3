package com.example.h3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class mainMenu extends AppCompatActivity {

    private Button order;
    private Button history;
    private Button profile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        order = (Button) findViewById(R.id.orderButton);
        history = (Button) findViewById(R.id.historyButton);
        profile = (Button) findViewById(R.id.profileButton);

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent scanScreen = new Intent(mainMenu.this, scanMenu.class);
                startActivity(scanScreen);
            }
        });

        history.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent historyMenu = new Intent(mainMenu.this, historyScreen.class);
                startActivity(historyMenu);
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent profileMenu = new Intent(mainMenu.this, profileScreen.class);
                startActivity(profileMenu);
            }
        });
    }
}
